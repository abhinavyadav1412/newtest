import React from "react";
import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import "./global.css";
import MarqueeSlider from "./components/marque";
import FAQSection from "./components/FAQ";
import Footer from "./components/Footer";

function App() {
  return (
    <div className="App">
      <Navbar />
      <HeroSection />
      
      {/* Main content container with proper z-index */}
      <main style={{ position: 'relative', zIndex: 10 }}>
        <MarqueeSlider />
        <FAQSection />
        <Footer />
      </main>
    </div>
  );
}

export default App;