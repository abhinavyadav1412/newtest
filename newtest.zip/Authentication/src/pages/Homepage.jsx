import React from 'react'
import Navbar from '../components/Navbar'
import "../global.css";

const Homepage = () => {
  return (
    <div>
        <Navbar/>
    </div>
  )
}

export default Homepage