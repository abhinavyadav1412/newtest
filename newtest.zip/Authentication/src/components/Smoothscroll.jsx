import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const SmoothScroll = ({ children }) => {
  const scrollContainer = useRef(null);

  useEffect(() => {
    const body = document.body;
    const html = document.documentElement;
    
    // Set initial styles
    gsap.set(body, { overflow: 'hidden' });
    gsap.set(html, { overflow: 'hidden' });
    gsap.set(scrollContainer.current, { position: 'fixed', width: '100%', height: '100%', top: 0, left: 0 });

    // Calculate total scrollable height
    const getMaxHeight = () => {
      let bodyHeight = body.scrollHeight;
      let htmlHeight = html.scrollHeight;
      return Math.max(bodyHeight, htmlHeight, scrollContainer.current.scrollHeight);
    };

    // Create smooth scroll effect
    let maxHeight = getMaxHeight();
    let proxy = { y: 0 };
    let scrollTo = 0;
    
    const updateScroller = () => {
      maxHeight = getMaxHeight();
      gsap.to(scrollContainer.current, { 
        y: -maxHeight + window.innerHeight,
        ease: 'none',
        scrollTrigger: {
          trigger: scrollContainer.current,
          start: 'top top',
          end: 'bottom bottom',
          scrub: 0.5,
          invalidateOnRefresh: true
        }
      });
    };

    ScrollTrigger.addEventListener('refreshInit', updateScroller);
    ScrollTrigger.addEventListener('refresh', updateScroller);
    ScrollTrigger.defaults({ scroller: scrollContainer.current });

    // Initial setup
    updateScroller();
    ScrollTrigger.refresh();

    return () => {
      ScrollTrigger.removeEventListener('refreshInit', updateScroller);
      ScrollTrigger.removeEventListener('refresh', updateScroller);
      ScrollTrigger.killAll();
      gsap.set([body, html], { overflow: 'auto' });
    };
  }, []);

  return <div ref={scrollContainer}>{children}</div>;
};

export default SmoothScroll;