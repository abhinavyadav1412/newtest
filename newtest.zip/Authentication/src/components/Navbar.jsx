import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
import './Navbar.css';

// Register GSAP plugins
gsap.registerPlugin(ScrollTrigger);

const Navbar = () => {
  const navbarRef = useRef(null);

  useEffect(() => {
    // Immediately make navbar visible
    gsap.set(navbarRef.current, { y: 0, opacity: 1 });

    // Scroll-triggered effects
    ScrollTrigger.create({
      trigger: "body",
      start: "top top",
      onUpdate: (self) => {
        if (self.scroll() > 50) {
          gsap.to(navbarRef.current, {
            backgroundColor: "rgba(65, 60, 221, 0.95)",
            backdropFilter: "blur(10px)",
            boxShadow: "0 4px 30px rgba(65, 60, 221, 0.95)",
            duration: 0.3
          });
        } else {
          gsap.to(navbarRef.current, {
            backgroundColor: "rgba(65, 60, 221, 0.95)",
            backdropFilter: "none",
            boxShadow: "none",
            duration: 0.3
          });
        }
      }
    });

    return () => ScrollTrigger.getAll().forEach(t => t.kill());
  }, []);

  return (
    <nav className="navbar" ref={navbarRef}>
      <div className="navbar-container">
        <motion.a
          href="#"
          className="logo"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          CarePulse
        </motion.a>

        <div className="nav-links">
          <a href="#" className="nav-link">Home</a>
          <a href="#about" className="nav-link">About</a>
          <a href="#features" className="nav-link">Features</a>
          <a href="#contact" className="nav-link">Contact</a>
        </div>

        <motion.button
          className="cta-button"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Get Started
        </motion.button>
      </div>
    </nav>
  );
};

export default Navbar;