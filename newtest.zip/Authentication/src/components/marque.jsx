import React from "react";
import "./MarqueeSlider.css";

const MarqueeSlider = () => {
  const cards = [
    { 
      id: 1, 
      title: "Instant Verification", 
      content: "Quickly authenticate medications with our simple scanning technology.",
      icon: "🔍"
    },
    { 
      id: 2, 
      title: "Blockchain Security", 
      content: "Tamper-proof records using decentralized blockchain technology.",
      icon: "⛓️"
    },
    { 
      id: 3, 
      title: "Mobile App", 
      content: "Easy-to-use app for verification anytime, anywhere.",
      icon: "📱"
    },
    { 
      id: 4, 
      title: "Healthcare Integration", 
      content: "Seamlessly integrates with existing healthcare systems.",
      icon: "⚕️"
    },
    { 
      id: 5, 
      title: "Analytics Dashboard", 
      content: "Comprehensive tracking and reporting tools.",
      icon: "📊"
    },
    { 
      id: 6, 
      title: "Regulatory Compliance", 
      content: "Meets all pharmaceutical industry standards and regulations.",
      icon: "✅"
    }
  ];

  const duplicatedCards = [...cards, ...cards];

  return (
    <div className="marquee-outer-container">
      <div className="marquee-wrapper">
        <div className="marquee-fade marquee-fade-left"></div>
        <div className="marquee-container">
          <div className="marquee-track">
            {duplicatedCards.map((card, index) => (
              <div 
                key={`${card.id}-${index}`} 
                className="marquee-card"
              >
                <div className="card-content">
                  <div className="card-icon">{card.icon}</div>
                  <h3>{card.title}</h3>
                  <p>{card.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="marquee-fade marquee-fade-right"></div>
      </div>
    </div>
  );
};

export default MarqueeSlider;